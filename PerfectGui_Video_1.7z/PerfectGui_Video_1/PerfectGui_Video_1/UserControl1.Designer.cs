﻿namespace PerfectGui_Video_1
{
    partial class UserControl_Home
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblHyperlink = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Roboto", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(149)))), ((int)(((byte)(242)))));
            this.label1.Location = new System.Drawing.Point(185, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(661, 239);
            this.label1.TabIndex = 0;
            this.label1.Text = "WELCOME TO HOME PAGE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHyperlink
            // 
            this.lblHyperlink.AutoSize = true;
            this.lblHyperlink.Font = new System.Drawing.Font("Roboto Thin", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHyperlink.LinkColor = System.Drawing.Color.White;
            this.lblHyperlink.Location = new System.Drawing.Point(907, 620);
            this.lblHyperlink.Name = "lblHyperlink";
            this.lblHyperlink.Size = new System.Drawing.Size(110, 19);
            this.lblHyperlink.TabIndex = 1;
            this.lblHyperlink.TabStop = true;
            this.lblHyperlink.Text = "CodeFromItaly";
            this.lblHyperlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblHyperlink_LinkClicked);
            // 
            // UserControl_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(41)))));
            this.Controls.Add(this.lblHyperlink);
            this.Controls.Add(this.label1);
            this.Name = "UserControl_Home";
            this.Size = new System.Drawing.Size(1017, 639);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel lblHyperlink;
    }
}
