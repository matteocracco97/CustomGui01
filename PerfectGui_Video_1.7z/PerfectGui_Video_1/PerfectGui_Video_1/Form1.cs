﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PerfectGui_Video_1
{
    public partial class MenuForm : Form
    {
        //drag and drop//
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        //



        UserControl_Home uc1;
        UserControl_news uc2;
        UserControl_Settings uc3;


        int pnlHome_min = 47;
        int pnlHome_max = 143;
        bool pnlHome_open = false;

        int pnlNews_min = 47;
        int pnlNews_max = 143;
        bool pnlNews_open = false;

        int pnlSettings_min = 47;
        int pnlSettings_max = 143;
        bool pnlSettings_open = false;

        public MenuForm()
        {
            InitializeComponent();
            System.Diagnostics.Process.Start("https://www.codefromitaly.com/");
            uc1 = new UserControl_Home();
            uc2 = new UserControl_news();
            uc3 = new UserControl_Settings();

           
            pnlMain.Controls.Add(uc1);
            pnlMain.Controls.Add(uc2);
            pnlMain.Controls.Add(uc3);

            uc1.BringToFront();
           
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void HomeBtn_Click(object sender, EventArgs e)
        {
            uc1.BringToFront();
            if (!pnlHome_open)
            {
                pnlHome.Height = pnlHome_max;
                pnlHome_open = true;
            }
            else
            {
                pnlHome.Height = pnlHome_min;
                pnlHome_open = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            uc3.BringToFront();

            if (!pnlSettings_open)
            {
                pnlSettings.Height = pnlSettings_max;
                pnlSettings_open = true;
            }
            else
            {
                pnlSettings.Height = pnlSettings_min;
                pnlSettings_open = false;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Designed by Code From Italy");
            System.Diagnostics.Process.Start("https://www.codefromitaly.com/");
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            uc2.BringToFront();
            if (!pnlNews_open)
            {
                pnlNews.Height = pnlNews_max;
                pnlNews_open = true;
            }
            else
            {
                pnlNews.Height = pnlNews_min;
                pnlNews_open = false;
            }
        }
    }
}
